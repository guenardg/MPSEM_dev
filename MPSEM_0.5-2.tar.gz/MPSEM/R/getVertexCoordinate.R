## **************************************************************************
##
##    (c) 2010-2024 Guillaume Guénard
##        Department de sciences biologiques,
##        Université de Montréal
##        Montreal, QC, Canada
##
##    ** Internal: Get Vertex Coordinates **
##
##    This file is part of MPSEM
##
##    MPSEM is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    MPSEM is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with MPSEM. If not, see <https://www.gnu.org/licenses/>.
##
##    R source code file
##
## **************************************************************************
##
## A function to calculate vertex coordinates suitable for plotting.
## This is an internal function; it as no formal R documentation.
getVertexCoordinate <- function(x) {
  
  ev <- attr(x,"ev")
  o <- getOrigin(x)
  
  x$vertex$type <- rep(2L,ev[2L])
  x$vertex$type[o] <- 1L
  x$vertex$type[getTerminal(x)] <- 3L
  
  imat <- InflMat(x)
  
  if(!is.null(x$edge$distance))
    imat <- t(t(imat)*sqrt(x$edge$distance))
  
  rawc <- svd(scale(imat,scale=FALSE),nu=2L,nv=0L)$u
  
  ord <- getVertexMinOrder(x)
  
  x$vertex$x <- numeric(ev[2L])
  x$vertex$y <- numeric(ev[2L])
  
  ## i=1L
  for(i in 1L:max(ord)) {
    
    wh <- which((ord == i) & (x$vertex$type != 3L))
    n <- length(wh)
    x$vertex$x[wh] <- seq(i - 0.25,i + 0.75,length.out=n)[order(rawc[wh,1L])]
    x$vertex$y[wh] <- seq(0,1,length.out=n)[order(rawc[wh,2L])]
    
  }
  
  i <- max(ord) + 1L
  wh <- which(x$vertex$type == 3L)
  n <- length(wh)
  x$vertex$x[wh] <- seq(i - 0.25,i + 0.75,length.out=n)[order(rawc[wh,2L])]
  x$vertex$y[wh] <- seq(0,1,length.out=n)[order(rawc[wh,1L])]
  
  x
}
