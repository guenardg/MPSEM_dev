## **************************************************************************
##
##    (c) 2010-2024 Guillaume Guénard
##        Department de sciences biologiques,
##        Université de Montréal
##        Montreal, QC, Canada
##
##    ** Random (Directed) Graph Generator **
##
##    This file is part of MPSEM
##
##    MPSEM is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    MPSEM is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with MPSEM. If not, see <https://www.gnu.org/licenses/>.
##
##    R source code file
##
## **************************************************************************
##
#' Random Graph Generator
#' 
#' @description A function for generating a random directed graph.
#' 
#' @name randomGraph
#' 
#' @param NV An integer. The number of vertices to generate.
#' @param NC A function with a \code{...} argument returning the maximum number
#' outgoing edges from each of the vertices; effectively determining the maximum
#' number of children vertices for any given vertex.
#' @param NP A function with a \code{...} argument returning the maximum number
#' of incoming edges to each of the vertices; effectively determining the
#' maximum number of parent vertices for any given vertex.
#' @param timestep A function with a \code{...} argument returning the amount of
#' time associated with the edges.
#' @param maxDist A function with a \code{...} argument returning the maximum
#' distances, in terms of time, allowed between any two parents vertices.
#' @param ... Any arguments to be passed internally to the functions given as
#' arguments \code{NC}, \code{NP}, \code{timestep}, or \code{maxDist}.
#' @param verbose A Boolean. Whether or not to print messages associated with
#' the graph simulation process (default: \code{TRUE}).
#' @param saveDist A Boolean. Whether or not to save the graph distance matrix
#' as an attribute to the returned \code{\link{graph-class}} object (default:
#' \code{TRUE}).
#' 
#' @details Details contents...
#' 
#' @returns A \code{\link{graph-class}} object.
#' 
#' @author \packageAuthor{MPSEM}
#' Maintainer: \packageMaintainer{MPSEM}
#' 
#' @seealso \code{\link{graph-class}}.
#' 
#' @examples ## Example here...
#' 
#' @export
randomGraph <- function(NV, NC, NP, timestep, maxDist, ..., verbose = TRUE,
                        saveDist = TRUE) {
  
  pop.graph(
    n = NV,
    vertex = list(
      species = rep(TRUE, NV),
      ncld = c(NC(...), rep(NA, NV - 1L))
    ),
    label = sprintf("V%d",1L:NV)
  ) -> x
  
  diss <- numeric(NV*(NV - 1L)/2L)
  
  ecnt <- 1L
  
  for(k in 2L:NV) {
    
    asc <- which(!is.na(x$vertex$ncld) & x$vertex$ncld > 0L)
    
    ## Checking for compatible ancestors:
    if(length(asc) > 1L) {
      np <- NP(...)
      md <- maxDist(...)
      s <- sample(asc, 1L)
      r <- asc[!(asc %in% s)]
      r <- r[diss[dst_idx(NV, s, r)] <= md]
      asc <- c(s,if(length(r) > (np - 1L)) sample(r, np - 1L) else r)
    }
    
    np <- length(asc)
    tstp <- numeric(np)
    for(i in 1L:np)
      tstp[i] <- timestep(...)
    
    for(i in 1L:np) {
      add.edge(
        x,
        from = asc[i],
        to = k,
        edge = list(distance = tstp[i]),
        label = sprintf("E%d",ecnt)
      ) -> x
      ecnt <- ecnt + 1L
      x$vertex$ncld[asc[i]] <- x$vertex$ncld[asc[i]] - 1L
    }
    
    x$vertex$ncld[k] <- NC(...)
    
    others <- (1L:k)[-c(asc,k)]
    
    if(length(others)) {
      dd <- diss[dst_idx(NV, asc[1L], others)] + tstp[1L]
      if(length(asc) > 1L) {
        ## Averaging the other paths:
        for(i in 2L:length(asc))
          dd <- dd + (diss[dst_idx(NV, asc[i], others)] + tstp[i])
        dd <- dd/length(asc)
      }
      diss[dst_idx(NV, k, others)] <- dd
    }

    diss[dst_idx(NV, asc, k)] <- tstp
    
    if(verbose) {
      message(sprintf("%d edges:\n", length(asc)))
      message(
        sprintf("\t%d -> %d (%f)\n", asc, k, tstp)
      )
      message("-----------------------\n")
    }
  }
  
  attr(x,"processOrder") <- 1L:NV
  
  if(saveDist)
    structure(
      diss,
      Size = NV,
      Labels = attr(x,"vlabel"),
      Diag = FALSE,
      Upper = FALSE,
      method = "patristic",
      class = "dist",
      call = match.call()
    ) -> attr(x,"dist")
  
  ## Filter-out the non-terminal vertices:
  x$vertex$species[x$edge[[1L]]] <- FALSE
  
  if(verbose)
    message(sum(x$vertex$species), " terminal vertices: ",
            paste(attr(x,"vlabel")[x$vertex$species], collapse=", "))
  
  x
}
##
