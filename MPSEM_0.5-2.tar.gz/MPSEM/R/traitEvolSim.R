## **************************************************************************
##
##    (c) 2023-2024 Guillaume Guénard
##        Department de sciences biologiques,
##        Université de Montréal
##        Montreal, QC, Canada
##
##    ** Trait Evolution Simulator **
##
##    This file is part of MPSEM
##
##    MPSEM is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    MPSEM is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with MPSEM. If not, see <https://www.gnu.org/licenses/>.
##
##    R source code file
##
## **************************************************************************
##
#' @name traitEvolSim
#' @aliases QTEM-class
#' 
#' @title Trait Evolution Simulator
#' 
#' @description Functions to simulate the evolution of traits as an
#' Ornstein-Uhlenbeck process, optionally with trait optimal value evolving
#' following a Markov process.
#' 
#' @param name Name of the trait whose evolution is to be created.
#' @param sigma Variance parameter of the trait (default: \code{sigma = 1}).
#' @param step Simulation step size (default: \code{step = 1}).
#' @param optima Trait optimal value(s) (default: \code{optima = NULL}).
#' @param alpha Trait selection rate (default: \code{alpha = 0}, meaning purely
#' neutral trait evolution)
#' @param transition A square, n-by-n, transition intensity matrix (default:
#' \code{transition = NULL}, which is suitable for single trait optima).
#' @param x A QTEM-class object.
#' @param ... further arguments to be passed to other functions and methods
#' 
#' @return Function \code{traitEvolSim} returns a QTEM-class object, which
#' consists of 8 member functions:
#' \describe{
#'   \item{\code{$getName}}{has no argument and returns the name of the trait,}
#'   \item{\code{$getStep}}{has no argument and returns the size of the
#'   simulation time step}
#'   \item{\code{$setStep}}{is given the time step as an argument and sets,
#'   the simulation time step, including the recalculation of the transition
#'   intensity matrix in the case of a trait with multiple optima,}
#'   \item{\code{$getOptima}}{has no argument and returns the trait optimum
#'   values,}
#'   \item{\code{getTransition}}{has no argument and returns the transition
#'   density matrix,}
#'   \item{\code{getProb}}{has no argument and returns the transition
#'   probability matrix,}
#'   \item{\code{$updateState}}{is given the index of the effective trait
#'   optimum and returns the updated index (allows shifts in trait optimum),}
#'   \item{\code{updateValue}}{is given the value of the trait and, optionally,
#'   the index of the optimum state, at returns the updated trait value,}
#'   \item{\code{dumpConfig}}{has no argument and returns the trait evolution
#'   simulator parameters as a list, and}
#'   \item{\code{print}}{has no argument and prints the parameters of the trait
#'   simulator on the screen (returns \code{NULL} invisibly).}
#' }
#' 
#' @details The trait evolution simulator is based on a random walk process of
#' one of categories: Weiner process and the Ornstein-Uhlenbeck process. The
#' Weiner process, also known as 'Brownian motion' is a random neutral process
#' with unbounded traits values. It is characterized using a single variance
#' parameter called \code{sigma} that dictates to what extent the trait value
#' fluctuates randomly in time.
#' 
#' The Ornstein-Uhlenbeck process is a random process with attractors (optima),
#' with values varying about these optima (or single optimum). It is notable
#' that whenever multiple optima are possible, only a single optimum is
#' effective at any given time. The Ornstein-Uhlenbeck process involve two more
#' values: the trait optimum effective at a particular time and the selection
#' rate (\code{alpha}). The optima represents the value toward which the
#' trait is attracted, whereas the value of \code{alpha} dictates to what
#' extent such an attraction occurs. When \code{alpha = 0}, the optimum stops
#' being an attractor and the Ornstein-Uhlenbeck process becomes purely a Weiner
#' process, whereas when \code{alpha} is very large, the trait value detracts
#' only slightly from its optimal value.
#' 
#' The trait simulation interface enabled to handle traits evolving neutrally
#' (pure Weiner process), and according to an Ornstein-Uhlenbeck process with
#' one or many optima. When many optima are used, transitions among the values
#' are simulated as a Markov process. For that purpose, the simulator needs to
#' be provided with a transition density matrix. 
#' 
#' @author \packageAuthor{MPSEM}
#' 
#' @importFrom stats rnorm
#' @importFrom expm expm
#' 
NULL
#' 
#' @rdname traitEvolSim
#' 
#' @examples
#' ## A list to contain the simulator objects:
#' tem <- list()
#' 
#' ## The first simulator is non-neutral with three optima:
#' traitEvolSim(
#'   name = "Trait 1",
#'   sigma = 1.5,
#'   alpha = 0.15,
#'   optima = c(30,50,80),
#'   transition = matrix(c(NA,0.1,0.0,0.1,NA,0.1,0.0,0.1,NA), 3L, 3L)
#' ) -> tem[[1]]
#' tem[[1]]
#' 
#' ## The second simulator is neutral:
#' traitEvolSim(
#'   name = "Trait 2",
#'   sigma = 2.5,
#'   step = 1
#' ) -> tem[[2]]
#' tem[[2]]
#' 
#' ## The third simulator is non-neutral with a single optimum:
#' traitEvolSim(
#'   name = "Trait 3",
#'   alpha = 0.05,
#'   optima = 15
#' ) -> tem[[3]]
#' tem[[3]]
#' 
#' ## The fourth simulator is also non-neutral with a single optimum (but having
#' ## a different value than the latter):
#' traitEvolSim(
#'   name = "Trait 4",
#'   sigma = 2.0,
#'   alpha = 0.25,
#'   optima = -25
#' ) -> tem[[4]]
#' tem[[4]]
#' 
#' ## Each simulator has a set of embedded member functions that can be called
#' ## directly.
#' 
#' ## Member $getName() returns the name of the trait as follows:
#' unlist(lapply(tem, function(x) x$getName()))
#' 
#' ## Member $getStep() returns the step sizes for the traits as follows:
#' unlist(lapply(tem, function(x) x$getStep()))
#' 
#' ## Member $setStep() sets the step sizes as follows:
#' lapply(tem, function(x) x$setStep(0.1))
#' 
#' ## and returns the recalculated transition probability matrix of simulators
#' ## having a transition intensity matrix (i.e., for non-neutral simulators
#' ## with multiple trait optima).
#' 
#' ## This is the modified step sizes:
#' unlist(lapply(tem, function(x) x$getStep()))
#' 
#' ## Member $getOptima() returns the simulator's optimum (if available) or a
#' ## vector of optima (if multiple optima are available) as follows:
#' lapply(tem, function(x) x$getOptima())
#' 
#' ## Member $getTransition() returns the transition intensity matrix, when
#' ## available (NULL otherwise) as follows:
#' lapply(tem, function(x) x$getTransition())
#' 
#' ## Member $getProb() returns the transition intensity matrix, whenever
#' ## available (NULL otherwise) as follows:
#' lapply(tem, function(x) x$getProb())
#' 
#' ## When multiple optima are available, member $updateState() enables to
#' ## simulate the transition from one optimal trait state (the one given as the
#' ## argument) to another (the one which is returned by the function):
#' state <- 1
#' newstate <- tem[[1]]$updateState(state)
#' newstate
#' 
#' ## Member $updateValue() simulates the evolution of the trait from one value
#' ## to another. For a non-neutral with multiple optima, The trait state is
#' ## provided using argument state (default: 1, which is the only applicable
#' ## value for a single optimum).
#' oldvalue <- 31.5
#' newvalue <- tem[[1]]$updateValue(oldvalue, state=1)
#' newvalue
#' 
#' ## Member $dumpConfig() returns the configuration list, which can be used
#' 
#' cfg <- lapply(tem, function(x) x$dumpConfig())
#' 
#' ## The trait evolution simulators can be re-instantiated as follows:
#' lapply(
#'   cfg,
#'   function(x)
#'     traitEvolSim(
#'       name = x$name,
#'       sigma = x$sigma,
#'       step = x$step,
#'       alpha = x$alpha,
#'       optima = x$optima,
#'       transition = x$transition
#'     )
#' ) -> tem_clone
#' 
#' ## Clean up:
#' rm(cfg, tem_clone)
#' 
#' ## Simulate trait evolution using the four simulators described previously:
#' 
#' ## Set step size to 0.05
#' lapply(tem, function(x, a) x$setStep(a), a = 0.05)
#' 
#' ## Results list:
#' res <- NULL
#' trNms <- lapply(tem, function(x) x$getName())
#' res$state <- matrix(NA, 1001L, length(tem), dimnames = list(NULL, trNms))
#' res$optim <- matrix(NA, 1001L, length(tem), dimnames = list(NULL, trNms))
#' res$trait <- matrix(NA, 1001L, length(tem), dimnames = list(NULL, trNms))
#' rm(trNms)
#' 
#' ## res$state contains the trait state at the simulation time
#' ## res$optim contains the trait's optimum value at the simulation time
#' ## res$trait contains the trait value at the simulation time
#' 
#' ## Setting the optimal state of the four traits at the beginning of the
#' ## simulation period:
#' res$state[1L,] <- c(2,NA,1,1)  ## NBL trait #2 evolves neutrally.
#' 
#' ## Getting the trait optima at the beginning of the simulation period:
#' unlist(
#'   lapply(
#'     tem,
#'     function(x)
#'       x$getOptima()[res$state[1L,x$getName()]]
#'   )
#' ) -> res$optim[1L,]
#' 
#' ## Setting the initial trait values:
#' res$trait[1L,] <- c(50,0,15,-25)
#' 
#' ## The state of the simulation at the beginning of the simulation:
#' head(res$state)
#' head(res$optim)
#' head(res$trait)
#' 
#' ## Setting RNG state to obtain 
#' set.seed(1234567)
#' 
#' ## This loop simulates time steps #2 through #1001
#' for(i in 2L:1001L) {
#'   
#'   ## Simulate the evolution of the trait states (if relevant, which it is
#'   ## only for the first trait):
#'   unlist(
#'     lapply(
#'       tem,
#'       function(x)
#'         x$updateState(res$state[i - 1L,x$getName()])
#'     ) 
#'   )-> res$state[i,]
#'   
#'   ## Obtain the optimal trait value (relevant for all traits but the second,
#'   ## trait, which evolves neutrally):
#'   unlist(
#'     lapply(
#'       tem,
#'       function(x)
#'         x$getOptima()[res$state[i,x$getName()]]
#'     )
#'   ) -> res$optim[i,]
#'   
#'   ## Simulate the evolution of the trait value:
#'   unlist(
#'     lapply(
#'       tem,
#'       function(x)
#'         x$updateValue(
#'           state = res$state[i,x$getName()],
#'           value = res$trait[i - 1L,x$getName()]
#'         )
#'     )
#'   ) -> res$trait[i,]
#' }
#' 
#' ## Plot the results:
#' par(mar=c(4,4,1,1))
#' plot(NA, xlim=c(0,0.05*1000), ylim=range(res$trait), xlab="Time",
#'      ylab="Trait value", las=1L)
#' lines(x=0.05*(0:1000), y=res$trait[,1L], col="black")
#' if(!is.na(tem[[1L]]$getOptima())[1L])
#'   lines(x=0.05*(0:1000), y=res$optim[,1L], col="black", lty=3L)
#' lines(x=0.05*(0:1000), y=res$trait[,2L], col="red")
#' if(!is.na(tem[[2L]]$getOptima())[1L])
#'   lines(x=0.05*(0:1000), y=res$optim[,2L], col="red", lty=3L)
#' lines(x=0.05*(0:1000), y=res$trait[,3L], col="blue")
#' if(!is.na(tem[[3L]]$getOptima())[1L])
#'   lines(x=0.05*(0:1000), y=res$optim[,3L], col="blue", lty=3L)
#' lines(x=0.05*(0:1000), y=res$trait[,4L], col="green")
#' if(!is.na(tem[[4L]]$getOptima())[1L])
#'   lines(x=0.05*(0:1000), y=res$optim[,4L], col="green", lty=3L)
#' 
#' ## Clean up
#' rm(res,tem,i,newstate,newvalue,oldvalue,state)
#' 
#' @export
traitEvolSim <- function(name, sigma = 1, step = 1, alpha = 0, optima = NULL,
                         transition = NULL) {
  
  if(sigma <= 0)
    stop("Argument 'sigma' value must be non-zero and positive!")
  
  if(step < 0)
    stop("Argument 'step' value must be positive!")
  
  if(alpha < 0)
    stop("Argument 'alpha' value must be positive!")
  
  if(is.null(optima) && (alpha != 0))
    stop("No optimal value provided for a non-neutral process!")
  
  nstate <- length(optima)
  
  if(nstate > 1L) {
    
    if(is.null(transition) || !is.matrix(transition))
      stop("Many optima provided without a transition intensity matrix!")
    
    if((NROW(transition) != length(optima)) ||
       (NROW(transition) != NCOL(transition)))
      stop("Inadequate transition matrix: ", NROW(transition), " by ",
           NCOL(transition), " for ", length(optima), " optima.")
    
    diag(transition) <- 0
    diag(transition) <- -rowSums(transition)
    prob <- expm(transition)
  } else
    prob <- NULL
  
  updateState <- function(state) {
    if(missing(state))
      stop("An initial state must be provided!")
    if(nstate > 1L)
      state <- sample(x=nstate, size=1L, prob=prob[state,])
    state
  }
  
  updateValue <- function(value, state = 1L) {
    if(missing(value))
      stop("No initial value!")
    if(alpha) {
      w <- exp(-alpha*step)
      s <- sigma*sqrt((1 - exp(-2*alpha*step))/(2*alpha))
      value <- rnorm(1L, w*value + (1 - w)*optima[state], s)
    } else {
      s <- sigma*sqrt(step)
      value <- rnorm(1L, value, s)
    }
    value
  }
  
  structure(
    list(
      getName = function() name,
      getStep = function() step,
      setStep = function(step) {
        step <<- step
        if(!is.null(transition))
          prob <<- expm(transition)
      },
      getOptima = function() if(is.null(optima)) NA else optima,
      getTransition = function() transition,
      getProb = function() prob,
      updateState = updateState,
      updateValue = updateValue,
      dumpConfig = function()
        list(
          name = name,
          sigma = sigma,
          step = step,
          alpha = alpha,
          optima = optima,
          transition = transition
        ),
      print = function() {
        cat("\nQuantitative trait evolution simulator (Ornstein-Uhlenbeck)",
            "\n----------------------------------------------\n")
        cat("Name:", name, "\n")
        if(alpha) {
          cat("Trait evolving non-neutrally (alpha = ",alpha,")\n",sep="")
        } else
          cat("Trait evolving neutrally (alpha = 0)\n")
        cat("Sigma = ",sigma,"\n",sep="")
        if(!is.null(optima))
          if(nstate > 1L) {
            cat("Trait optima:",paste(optima,collapse=", "),"\n")
          } else
            cat("Trait optimum:",optima,"\n")
        if(!is.null(transition)) {
          cat("Transition intensity matrix:\n")
          print(transition)
        }
        cat("\n")
        invisible(NULL)
      }
    ),
    class = "QTEM"
  )
}
#' 
#' @rdname traitEvolSim
#' 
#' @method print QTEM
#' 
#' @export
print.QTEM <- function(x, ...)
  x$print()
#' 
